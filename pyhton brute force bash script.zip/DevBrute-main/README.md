# **DevBrute - A Password Brute Forcer**

### VERSION 1.0

## Introduction

DevBrute is my casual and random project in Infomation Security. The whole project is in the Python Programming Language which is built for Brute Forcing the Passwords of Web Applications. Nowadays, Brute Forcing on any Web Applications is like wasting time because most web apps uses plethora of techniques to prevent brute forcing on their websites. You can notice a common technique on most websites which is **Locking Account**. You might use one of greatest brute force tool or You might found some password but in those two scenario, it always depends on websites.


# **INSTALLATION**

The installation of this tool is easy and you can install this tool in just three steps. 

### 1. CLONE THE REPOSITORY
```
git clone https://github.com/shivamksharma/DevBrute.git
```

### 2. INSTALL THE REQUIREMENTS
```
pip3 install -r setup.py

#In Case `pip3` is unavailable on your system then install it first by typing :
sudo apt-get install python3-pip
```

### 3. RUN DEVBRUTE
```
python3 devbrute.py -s -username -w

-s : WEBSITE's URL
-username : USERNAME
-w : Wordlist
```

### FIXES
	- Fixed some bugs
	- Fixed Website URLS Error
	- Fixed Wordlist Issue

> **This project is no longer in development. If You want to contribute to this project then feel free to contribute to it by implementations.**
