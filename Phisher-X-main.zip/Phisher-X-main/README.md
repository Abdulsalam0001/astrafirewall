# Phisher-X
A phishing tool.

**ngrok related errors are temporary and can be resolved but there are alternatives that consume lesser time when it comes to setting up. Head over to the 'Setup' section to know more about those alternatives.**


        _   _   _   _   _   _   _   _   _  
       / \ / \ / \ / \ / \ / \ / \ / \ / \ 
      ( P | h | i | s | h | e | r | - | X )
       \_/ \_/ \_/ \_/ \_/ \_/ \_/ \_/ \_/ 
       

## Features ##

# Latest and updated login pages

- Traditional Snapchat Login page.

- Gmail login page

- Instagram; traditional login page, increase followers 1, increase followers 2.

- Kik; login page, ragebot unbrik page, anvil unbrick page, mediafire login page.

- Facebook; login page, messenger login page.

- Dropbox login page.

- PayPal login page.

- Tiktok login page.

- Steam login page.

- Linkdin login page.

(More pages will be added later)

* Mask URL support

* Beginner Friendly

* Easy to setup

## Installation ##

Clone the repository; 
```
$ git clone https://github.com/Sitiaro/Phisher-X
```
Change to clone directory, give the exec file permissions and run phisherx.sh;
```
$ cd Phisher-X
```
```
$ chmod +x phisherx.sh
```
```
$ ./phisherx.sh
```
On first install, it'll install all the dependencies after which you'll be able to use the tool.

## Setup ##

## 1. Replit ##

Head over to **https://replit.com/** or download the replit app from play store and sign up for an account, or sign up with google (preferred). After you finish setting the account up, click on the 3 bars on top right corner and select 'create repl'. On the setup box, click on 'import from Github' (on top right corner of the box), and paste the url of this repository **https://www.github.com/Sitiaro/Phisher-X** in the box, and click import. Once it finishes importing, it'll ask you to enter the language and configure the run button. Leave the language part alone and set 'configure the run button' to bash phisherx.sh

Once this is done, click on 'shell' and enter this: **php -S 0.0.0.0:80**

**If you get a 'No such files or directory exist', then run this command on the shell in place of the one mentioned above:-**

**php -S localhost:80 -t .server**


**If it shows a request not found then skip the above mentioned step and start the tool first. Once the tool starts and you select whatever page you want to use, input the above mentioned command.**

A new window will pop up right above the shell option. Once it does, click the big green play button on your replit page and watch it work~

**You can close the script using ctrl+c and run it again using the play button without having to do the shell steps again. However, the page won't work if your replit gets disconnected so keep checking 'shell' every so often, and make sure to check the replit tab because it goes to sleep every now and then.**


## 2. Termux ##

For this you need to download termux on your Android device. Click [here](https://f-droid.org/repo/com.termux_118.apk) to download the latest version of termux. Once the download finishes, follow the steps mentioned under the **Installation** section.

**Cloudflared faces some issues every so often so check the link being generated on yourself before sending it to the victim.**


## Dependencies ##

Phisher-X requires the following packages to function;

php

wget

curl

git


**More phishing pages TBA**
